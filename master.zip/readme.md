# Original Plugin Developer

* Twitter: [@ricard_dev](http://twitter.com/ricard_dev)
* Blog: [Rick's code](http://php.quicoto.com/)

## Thumbs Rating
Contributors: quicoto
Tags: ratings, thumbs, votes, AJAX, rating, thumb, vote, page, post
Requires at least: 4.5
Tested up to: 4.7
Stable tag: 3.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Thumbs Rating does what you'd expect. It allows you to add a thumbs up/down to your content (posts, pages, custom post types...).

## Description

A simple and light plugin to add Thumbs Rating.

This plugin allows you to add a thumb up/down rating to your content. You can set it up to show anywhere you want.
